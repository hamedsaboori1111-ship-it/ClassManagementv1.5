package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.security.SecurityManager
import com.example.ui.theme.PrimaryGreen
import kotlin.math.sqrt

@Composable
fun PatternLockView(
    modifier: Modifier = Modifier,
    isError: Boolean = false,
    isSuccess: Boolean = false,
    enabled: Boolean = true,
    onPatternCompleted: (List<Int>) -> Unit
) {
    val context = LocalContext.current
    val selectedNodes = remember { mutableStateListOf<Int>() }
    var currentTouchPoint by remember { mutableStateOf<Offset?>(null) }

    // Clear pattern automatically if external states reset
    LaunchedEffect(isError) {
        if (isError) {
            SecurityManager.vibrate(context, 80)
            kotlinx.coroutines.delay(800)
            selectedNodes.clear()
            currentTouchPoint = null
        }
    }

    LaunchedEffect(isSuccess) {
        if (isSuccess) {
            SecurityManager.vibrate(context, 30)
        }
    }

    val lineColor by animateColorAsState(
        targetValue = when {
            isError -> Color(0xFFEF4444)
            isSuccess -> Color(0xFF10B981)
            else -> PrimaryGreen
        },
        label = "lineColor"
    )

    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(1f)
            .padding(16.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectDragGestures(
                    onDragStart = { offset ->
                        selectedNodes.clear()
                        currentTouchPoint = offset
                        val node = findNodeAtOffset(offset, size.width.toFloat(), size.height.toFloat())
                        if (node != null && !selectedNodes.contains(node)) {
                            selectedNodes.add(node)
                            SecurityManager.vibrate(context, 20)
                        }
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        currentTouchPoint = change.position
                        val node = findNodeAtOffset(change.position, size.width.toFloat(), size.height.toFloat())
                        if (node != null && !selectedNodes.contains(node)) {
                            selectedNodes.add(node)
                            SecurityManager.vibrate(context, 20)
                        }
                    },
                    onDragEnd = {
                        currentTouchPoint = null
                        if (selectedNodes.isNotEmpty()) {
                            onPatternCompleted(selectedNodes.toList())
                        }
                    },
                    onDragCancel = {
                        currentTouchPoint = null
                        selectedNodes.clear()
                    }
                )
            }
    ) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        Canvas(modifier = Modifier.fillMaxSize()) {
            val nodeRadius = 10.dp.toPx()
            val outerRadius = 26.dp.toPx()
            val hitRadius = 38.dp.toPx()
            val strokeWidth = 5.dp.toPx()

            // Pre-calculate positions of the 9 nodes (3x3 grid)
            val stepX = width / 3f
            val stepY = height / 3f
            val nodeOffsets = (0..8).map { index ->
                val col = index % 3
                val row = index / 3
                Offset(stepX * (col + 0.5f), stepY * (row + 0.5f))
            }

            // Draw connecting lines between selected nodes
            if (selectedNodes.size > 1) {
                for (i in 0 until selectedNodes.size - 1) {
                    val start = nodeOffsets[selectedNodes[i]]
                    val end = nodeOffsets[selectedNodes[i + 1]]
                    drawLine(
                        color = lineColor,
                        start = start,
                        end = end,
                        strokeWidth = strokeWidth,
                        cap = StrokeCap.Round
                    )
                }
            }

            // Draw line to current touch point
            currentTouchPoint?.let { touchPos ->
                if (selectedNodes.isNotEmpty()) {
                    val lastNodeOffset = nodeOffsets[selectedNodes.last()]
                    drawLine(
                        color = lineColor.copy(alpha = 0.8f),
                        start = lastNodeOffset,
                        end = touchPos,
                        strokeWidth = strokeWidth * 0.85f,
                        cap = StrokeCap.Round
                    )
                }
            }

            // Draw 9 nodes
            nodeOffsets.forEachIndexed { index, offset ->
                val isSelected = selectedNodes.contains(index)
                if (isSelected) {
                    // Outer highlighted ring
                    drawCircle(
                        color = lineColor.copy(alpha = 0.22f),
                        radius = outerRadius,
                        center = offset
                    )
                    drawCircle(
                        color = lineColor,
                        radius = outerRadius,
                        center = offset,
                        style = Stroke(width = 2.dp.toPx())
                    )
                    // Inner filled circle
                    drawCircle(
                        color = lineColor,
                        radius = nodeRadius,
                        center = offset
                    )
                } else {
                    // Normal idle node dot
                    drawCircle(
                        color = Color(0xFFCBD5E1),
                        radius = nodeRadius * 0.75f,
                        center = offset
                    )
                }
            }
        }
    }
}

private fun findNodeAtOffset(offset: Offset, width: Float, height: Float): Int? {
    val stepX = width / 3f
    val stepY = height / 3f
    val hitRadius = width / 6.5f

    for (index in 0..8) {
        val col = index % 3
        val row = index / 3
        val nodeCenter = Offset(stepX * (col + 0.5f), stepY * (row + 0.5f))
        val dist = sqrt((offset.x - nodeCenter.x) * (offset.x - nodeCenter.x) + (offset.y - nodeCenter.y) * (offset.y - nodeCenter.y))
        if (dist <= hitRadius) {
            return index
        }
    }
    return null
}
