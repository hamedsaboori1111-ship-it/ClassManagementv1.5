package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.LayoutDirection
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.SecurityManager
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ClassViewModel

class MainActivity : FragmentActivity() {

    private val viewModel: ClassViewModel by viewModels()
    private val isAppUnlockedState = mutableStateOf(false)

    // با فشردن دکمه قفل گوشی (خاموش شدن صفحه)، برنامه کاملاً بسته می‌شود
    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                if (SecurityManager.isSecurityActive(this@MainActivity)) {
                    isAppUnlockedState.value = false
                }
                finishAffinity()
                finishAndRemoveTask()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // روشن ماندن صفحه گوشی و آماده به کار بودن برنامه تا زمانی که خود معلم صفحه را قفل نکرده است
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // ثبت گیرنده رویداد خاموش/قفل شدن صفحه گوشی جهت خروج کامل از برنامه
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenOffReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenOffReceiver, filter)
        }

        // مقداردهی وضعیت قفل اولیه بر اساس فعال بودن امنیت
        isAppUnlockedState.value = !SecurityManager.isSecurityActive(this)

        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            MyApplicationTheme(themeMode = state.themeMode) {
                // جهت‌بندی راست‌به‌چپ (RTL) برای زبان فارسی، مطابق کدهای فلاتر
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        ClassManagerApp(
                            viewModel = viewModel,
                            isAppUnlockedState = isAppUnlockedState,
                            onExitApp = {
                                if (SecurityManager.isSecurityActive(this)) {
                                    isAppUnlockedState.value = false
                                }
                                finishAffinity()
                                finishAndRemoveTask()
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // اگر خروج موقت برای انتخاب فایل بک‌آپ یا تصویر از حافظه گوشی است، برنامه قفل یا بسته نمی‌شود
        if (SecurityManager.isBypassActive()) {
            return
        }
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (powerManager != null && !powerManager.isInteractive) {
            // گوشی قفل یا خاموش شده است -> بستن کامل برنامه
            if (SecurityManager.isSecurityActive(this)) {
                isAppUnlockedState.value = false
            }
            finishAffinity()
            finishAndRemoveTask()
            return
        }
        // هنگامی که کاربر از فضای برنامه خارج می‌شود یا برنامه به پس‌زمینه می‌رود، در صورت فعال بودن امنیت قفل شود
        if (SecurityManager.isSecurityActive(this)) {
            isAppUnlockedState.value = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(screenOffReceiver)
        } catch (e: Exception) {
            // نادیده گرفتن در صورت لغو ثبت قبلی
        }
    }
}

@Composable
fun ClassManagerApp(
    viewModel: ClassViewModel,
    isAppUnlockedState: MutableState<Boolean>,
    onExitApp: () -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()

    val isAppUnlocked by isAppUnlockedState
    val isSecurityActive = SecurityManager.isSecurityActive(context)

    val isInitialSetupDone = remember { SecurityManager.isInitialSetupDone(context) }
    var currentScreen by remember {
        mutableStateOf(if (!isInitialSetupDone) Screen.PROFILE_SETTINGS else Screen.HOME)
    }

    var lastBackPressTime by remember { mutableLongStateOf(0L) }

    if (!isAppUnlocked && isSecurityActive) {
        AppLockScreen(
            teacherName = state.profile.teacherName,
            schoolName = state.profile.schoolName,
            onUnlock = { isAppUnlockedState.value = true }
        )
        return
    }

    // مدیریت دکمه بازگشت اندروید: با دو بار فشردن متوالی در صفحه اصلی، برنامه کاملاً بسته شده و در پس‌زمینه فعال نمی‌ماند
    BackHandler(enabled = true) {
        if (currentScreen != Screen.HOME) {
            currentScreen = Screen.HOME
        } else {
            val now = System.currentTimeMillis()
            if (now - lastBackPressTime < 2000L) {
                onExitApp()
            } else {
                lastBackPressTime = now
                android.widget.Toast.makeText(
                    context,
                    "برای خروج کامل از برنامه، دوباره دکمه بازگشت را بزنید",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    AnimatedContent(
        targetState = currentScreen,
        label = "ScreenTransition"
    ) { screen ->
        when (screen) {
            Screen.HOME -> {
                HomeScreen(
                    state = state,
                    onNavigate = { currentScreen = it },
                    onDateChange = { viewModel.setDate(it) },
                    onDayTypeChange = { viewModel.setDayType(it) },
                    onExportBackup = { viewModel.exportDataJson() },
                    onImportBackup = { viewModel.importDataJson(it) },
                    onSyncWithDeviceDate = { viewModel.syncWithDeviceDate() },
                    onThemeChange = { viewModel.setThemeMode(it) }
                )
            }
            Screen.PROFILE_SETTINGS -> {
                ProfileSettingsScreen(
                    profile = state.profile,
                    onBack = { currentScreen = Screen.HOME },
                    onSaveProfile = { teacherName, educationalTitle, schoolName ->
                        viewModel.updateProfileSettings(teacherName, educationalTitle, schoolName)
                    }
                )
            }
            Screen.SCHEDULE -> {
                WeeklyScheduleScreen(
                    weeklySchedule = state.weeklySchedule,
                    availableSubjects = state.subjects,
                    onBack = { currentScreen = Screen.HOME },
                    onSaveSchedule = { updatedSchedule ->
                        viewModel.updateWeeklySchedule(updatedSchedule)
                    }
                )
            }
            Screen.ATTENDANCE -> {
                AttendanceScreen(
                    students = state.students,
                    currentDate = state.currentDateShamsi,
                    attendanceHistory = state.attendanceHistory,
                    onBack = { currentScreen = Screen.HOME },
                    onStatusChange = { id, status -> viewModel.updateStudentAttendance(id, status) },
                    onMarkAllPresent = { viewModel.markAllStudentsPresent() },
                    onAddStudent = { name, shad, month -> viewModel.addStudent(name, shad, month) },
                    onSaveStudent = { student -> viewModel.addStudent(student) },
                    onUpdateStudent = { student -> viewModel.updateStudent(student) },
                    onDeleteStudent = { viewModel.deleteStudent(it) },
                    onUpdateHistoricalAttendance = { date, id, status ->
                        viewModel.updateHistoricalAttendance(date, id, status)
                    },
                    onMarkAllPresentForDate = { date ->
                        viewModel.markAllPresentForDate(date)
                    },
                    onAddHistoricalDate = { date ->
                        viewModel.addHistoricalAttendanceDate(date)
                    },
                    onDeleteHistoricalDate = { date ->
                        viewModel.deleteHistoricalAttendanceDate(date)
                    },
                    onSubmitAttendance = { date, records ->
                        viewModel.submitDailyAttendance(date, records)
                    },
                    onSaveHistoricalAttendance = { date, records ->
                        viewModel.saveHistoricalAttendance(date, records)
                    },
                    onNavigateToPro = { currentScreen = Screen.PRO_ACTIVATION }
                )
            }
            Screen.EVALUATION -> {
                EvaluationScreen(
                    students = state.students,
                    subjects = state.subjects,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME },
                    onAddEvaluation = { id, subject, type, score, date ->
                        viewModel.addEvaluation(id, subject, type, score, date)
                    },
                    onDeleteEvaluation = { studentId, evalId ->
                        viewModel.deleteEvaluation(studentId, evalId)
                    }
                )
            }
            Screen.GROUPS -> {
                GroupScoresScreen(
                    groups = state.groups,
                    students = state.students,
                    justiceLeague = state.justiceLeague,
                    onBack = { currentScreen = Screen.HOME },
                    onScoreChange = { index, delta -> viewModel.updateGroupScore(index, delta) },
                    onAddGroup = { name, members -> viewModel.addGroup(name, members) },
                    onUpdateGroup = { index, name, members -> viewModel.updateGroup(index, name, members) },
                    onDeleteGroup = { viewModel.deleteGroup(it) },
                    onDrawJusticeLeague = { viewModel.drawJusticeLeagueStudent() },
                    onStartNewLeague = { viewModel.startNewJusticeLeague() },
                    onResetLeague = { viewModel.resetJusticeLeagueCurrentRound() }
                )
            }
            Screen.SUBJECTS -> {
                SubjectManagementScreen(
                    subjects = state.subjects,
                    onBack = { currentScreen = Screen.HOME },
                    onToggle = { id, enabled -> viewModel.toggleSubject(id, enabled) },
                    onRename = { id, newName -> viewModel.updateSubjectName(id, newName) },
                    onAddSubject = { viewModel.addSubject(it) },
                    onDeleteSubject = { viewModel.deleteSubject(it) }
                )
            }
            Screen.NOTES -> {
                TeacherNotesScreen(
                    notes = state.teacherNotes,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME },
                    onAddNote = { title, content, date -> viewModel.addTeacherNote(title, content, date) },
                    onDeleteNote = { viewModel.deleteTeacherNote(it) }
                )
            }
            Screen.MEETINGS -> {
                ParentMeetingsScreen(
                    meetings = state.parentMeetings,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME },
                    onAddMeeting = { title, date, summary -> viewModel.addParentMeeting(title, date, summary) },
                    onDeleteMeeting = { viewModel.deleteParentMeeting(it) }
                )
            }
            Screen.PERFORMANCE -> {
                StudentPerformanceScreen(
                    students = state.students,
                    subjects = state.subjects,
                    attendanceHistory = state.attendanceHistory,
                    groups = state.groups,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME }
                )
            }
            Screen.CHARTS -> {
                ClassChartsScreen(
                    students = state.students,
                    subjects = state.subjects,
                    attendanceHistory = state.attendanceHistory,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME }
                )
            }
            Screen.BACKUP_RESTORE -> {
                BackupRestoreScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = Screen.HOME },
                    onNavigateToPro = { currentScreen = Screen.PRO_ACTIVATION }
                )
            }
            Screen.PRO_ACTIVATION -> {
                ProActivationScreen(
                    onBack = { currentScreen = Screen.HOME }
                )
            }
            Screen.BUDGETING -> {
                CurriculumBudgetingScreen(
                    subjects = state.subjects,
                    budgetings = state.subjectBudgetings,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME },
                    onSaveBudgeting = { updatedList ->
                        viewModel.saveSubjectBudgetings(updatedList)
                    }
                )
            }
            Screen.STUDENTS_LIST -> {
                StudentsListScreen(
                    students = state.students,
                    onBack = { currentScreen = Screen.HOME },
                    onReorderStudents = { updatedList -> viewModel.reorderStudents(updatedList) },
                    onAddStudent = { student -> viewModel.addStudent(student) },
                    onUpdateStudent = { student -> viewModel.updateStudent(student) },
                    onDeleteStudent = { id -> viewModel.deleteStudent(id) },
                    onNavigateToPro = { currentScreen = Screen.PRO_ACTIVATION }
                )
            }
        }
    }
}

// Greeting function kept for backward test compatibility
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme { Greeting("دفتر مدیریت کلاس") }
}
